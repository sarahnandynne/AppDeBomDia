﻿namespace sarah;

public partial class MainPage : ContentPage
{
List<String> frases = new List<string>();
  string? fraseGerada = null;

	public MainPage()
	{
		InitializeComponent();

		frases.Add("Bom dia! Que seu dia seja repleto de coisas boas!");
		frases.Add("Que você tenha sabedoria para fazer as melhores escolhas! Tenha um ótimo dia!");
		frases.Add("Mais um dia começando! Que seu dia seja cheio de boas oportunidades");
		frases.Add("Um novo dia é sinônimo de uma nova chance. Que Deus te guie em todos os momentos de hoje.");
		frases.Add("Bom dia para você que acordou com a certeza de que dias melhores virão!");

	}


	void Button_Clicked(object sender, EventArgs args)
	{
   int indice = Random.Shared.Next(0,4);
    fraseGerada = frases[indice];
    labelMsg.Text = fraseGerada;
    }


private void BotaoGerarFoiClicado(object sender, EventArgs args)
  {
    int indice = Random.Shared.Next(0,4);
    fraseGerada = frases[indice];
    labelMsg.Text = fraseGerada;
  }


private async void BotaoCompartilharFoiClicado(object sender, EventArgs args)
  {
    if (fraseGerada != null)
    {
      await Share.Default.RequestAsync(new ShareTextRequest()
      {
          Text = fraseGerada,
          Title = "Gerador de Frases"
	  });

	}
  }

}	